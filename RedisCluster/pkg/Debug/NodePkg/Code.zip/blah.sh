#!/bin/bash

/usr/bin/node node.js 2>&1  $Fabric_Folder_App_Log/temp.txt